import {
  getTimeString,
} from "../helpers/flightUtils";
import { verifyEvent } from '../helpers/verifyEvent';
import { htmlFromString } from '../helpers/htmlStringConvert';
import { Flight } from "../types";

export function renderFlightRow(flight: Flight, onClick: (flight: Flight) => void) {
  const flightCard = new FlightRow({
    flight,
    onRowClick: onClick
  });
  return flightCard.render();
}

interface FlightRowConfig {
  flight: Flight;
  onRowClick: (flight: Flight) => void;
}

class FlightRow {
  flight: Flight;
  onRowClick: (flight: Flight) => void;

  constructor(config: FlightRowConfig) {
    this.flight = config.flight;
    this.onRowClick = config.onRowClick;

    document.body.addEventListener('click', this.onClick.bind(this));
  }

  onClick(ev: Event) {
    if (verifyEvent(ev, this.flight.flight_number.toLowerCase())) {
      this.onRowClick(this.flight);
    }
  }

  /**
   * Render flight details.
   */
  render(): HTMLElement {
    const flight = this.flight;

    return htmlFromString(`
      <tr data-${flight.flight_number.toLowerCase()}>
        <td>${flight.flight_number}</td>
        <td>${flight.airline}</td>
        <td>${flight.origin_code}</td>
        <td>${flight.destination_code}</td>
        <td>${getTimeString(flight.current_departure_time)}</td>
        <td>${getTimeString(flight.current_arrival_time)}</td>
        <td>${flight.flight_status}</td>
      </tr>`
    );
  }

}
