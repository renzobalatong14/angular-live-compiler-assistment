import {
  getTimeString,
  getFlightDurationString,
} from "../helpers/flightUtils";
import { verifyEvent } from '../helpers/verifyEvent';
import { htmlFromString } from '../helpers/htmlStringConvert';
import { SelectedFlightData } from '../data/selectedFlightData';
import { Flight } from "../types";

export function renderFlightCard(selectedFlightData: SelectedFlightData) {
  const flightCard = new FlightCard({
    flight: selectedFlightData.get('flight'),
    onBackClick: () => selectedFlightData.set('flight', null),
  });
  return flightCard.render();
}

interface FlightCardConfig {
  flight: Flight;
  onBackClick: () => void;
}

class FlightCard {
  flight: Flight;
  onBackClick: () => void;

  constructor(config: FlightCardConfig) {
    this.flight = config.flight;
    this.onBackClick = config.onBackClick;

    document.body.addEventListener('click', this.onClick.bind(this));
  }

  onClick(ev: Event) {
    if (verifyEvent(ev, 'back')) {
      this.onBackClick();
    }
  }

  /**
   * Render flight details.
   */
  render(): HTMLElement {
    const flight = this.flight;

    return htmlFromString(`
      <div class="flight-card">
      <nav>
        <button class="button-back" data-back>
          Back
        </button>
      </nav>
      <header class="flight-card-header">
        <h2>Flight ${flight.flight_number}</h2>
        <h2>
          ${flight.origin_code} - ${flight.destination_code}
        </h2>
      </header>
      <div class="flight-card-body">
        <section class="flight-card-section">
          <h3 class="flight-card-section-header">Flight Summary</h3>
          <div class="flight-card-section-content">
            <p>Airline: ${flight.airline}</p>
            <p>
              Departure Time: ${getTimeString(flight.current_departure_time)}
              ${flight.flight_status === "Delayed" ? (`
                <span>
                   (was ${getTimeString(flight.scheduled_departure_time)})
                </span>
              `) : ''}
            </p>
            <p>
              Arrival Time: 
              ${flight.flight_status === "Cancelled"
                ? "-"
                : getTimeString(flight.current_arrival_time)}
              ${flight.flight_status === "Delayed" ? (
                `<span>
                   (was ${getTimeString(flight.scheduled_arrival_time)})
                </span>`
              ) : ''}
            </p>
            <p>Flight Status: ${flight.flight_status}</p>
            <p>
              Flight Duration: ${getFlightDurationString(flight.flight_duration)}
            </p>
          </div>
        </section>
      </div>
    </div>
    `);
  }

}
