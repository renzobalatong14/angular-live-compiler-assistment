import { renderHeader } from './header';
import { renderFlightRow } from './flightRow';
import { htmlFromString, stringFromHtml } from '../helpers/htmlStringConvert';
import { ResultsData } from '../data/resultsData';
import { SelectedFlightData } from '../data/selectedFlightData';
import { Flight } from '../types';


/**
 * The root element for this component.
 */
let rootEl: HTMLElement | undefined;
let setSelectedFlight: ((flight: Flight) => void) | undefined;


/** An instance of the resultsData object for state management */
export const resultsData = new ResultsData({
  onChange: handleDataChange,
});

/**
 * Re-renders the content of the rootEl when a data property changes
 */
function handleDataChange(key: string) {
  if (rootEl && (key === 'flights' || key === 'view')) {
    rootEl.replaceWith(renderFlightDashboard());
  }
}

/**
 * Renders the flight table page
 */
export function renderFlightDashboard(selectedFlightData?: SelectedFlightData): HTMLElement {
  if (selectedFlightData !== undefined) {
    setSelectedFlight = (flight: Flight) => {
      selectedFlightData.set('flight', flight);
    }
  }
 
  const flights: Flight[] = resultsData.get('flights');

  rootEl = htmlFromString(`
   <div>
      ${stringFromHtml(renderHeader())}
      <section class="dashboard-container"><table>
            <thead>
              <tr>
                <th scope="col">Flight Number</th>
                <th scope="col">Airline</th>
                <th scope="col">Origin</th>
                <th scope="col">Destination</th>
                <th scope="col">Current Departure</th>
                <th scope="col">Current Arrival</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              ${flights.map((flight) => stringFromHtml(renderFlightRow(flight, setSelectedFlight))).join('')}
            </tbody>
          </table>
      </section>
    </div>
  `);

  return rootEl;
}
