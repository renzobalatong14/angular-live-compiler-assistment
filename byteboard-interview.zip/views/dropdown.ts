import {htmlFromString} from '../helpers/htmlStringConvert';
import {verifyEvent} from '../helpers/verifyEvent';

interface DropdownConfig {
  type: string;
  options: string[];
  selected?: number;
  onSelect?: (selected: SelectedOption) => void;
}

export interface SelectedOption {
  type: string;
  value: number;
  display: string;
}

/**
 * Converts an array into select option elements, as a string
 */
function mapSelectOptions(set: string[], selectedIndex: number = 0): string {
  return set
    .map((option, i) => {
      return `
        <option${i === Number(selectedIndex) ? ' selected' : ''} value=${i}>
          ${option}
        </option>
      `;
    })
    .join('');
}

export class Dropdown {
  type: string;
  dataProp: string;
  options: string[];
  selectedIndex: number;
  callback?: (selected: SelectedOption) => void;

  constructor(config: DropdownConfig) {
    this.type = config.type;
    this.dataProp = config.type.replace(/\s/g, "").toLowerCase();
    this.options = config.options;
    this.selectedIndex = config.selected || 0;
    this.callback = config.onSelect;

    document.body.addEventListener('change', this.onSelect.bind(this));
  }

  /**
   * Renders the dropdown component
   */
  render(): HTMLElement | null {
    if (!this.options) return null;

    return htmlFromString(`
      <div class="dropdown">
        ${this.type ? `<label>${this.type.replace('_', ' ')}</label>` : ''}
        <select class="custom-select" data-${this.dataProp}>
          ${mapSelectOptions(this.options, this.selectedIndex)}
        </select>
      </div>
    `);
  }

  /**
   * Handles changes to the selected option
   */
  onSelect(ev: Event) {
    if (verifyEvent(ev, this.dataProp)) {
      this.selectedIndex = parseInt((<HTMLSelectElement>ev.target).value);

      if (this.callback) {
        this.callback(this.getSelected());
      }
    }
  }

  /**
   * Returns the currently selected value index and display string
   */
  getSelected(): SelectedOption {
    return {
      type: this.type,
      value: this.selectedIndex,
      display: this.options[this.selectedIndex],
    };
  }
}
