import {htmlFromString, stringFromHtml} from '../helpers/htmlStringConvert';
import {Dropdown, SelectedOption} from './dropdown';
import {resultsData} from './flightDashboard';
import {verifyEvent} from '../helpers/verifyEvent';
import { viewOptions } from '../data/constants';

/** The root element for this component. */
let rootEl: HTMLElement;

function onClickReset(ev: Event) {
  if (verifyEvent(ev, 'headerReset')) {
    resultsData.set('view', 0);
    rootEl.replaceWith(renderHeader());
  }
}

function onSelectView(selected: SelectedOption) {
  resultsData.set('view', selected.value);
}

export function renderHeader(): HTMLElement {
  document.body.addEventListener('click', onClickReset);

  const viewPicker = new Dropdown({
    type: 'View',
    options: viewOptions,
    selected: resultsData.get('view'),
    onSelect: onSelectView,
  });

 
  rootEl = htmlFromString(`
    <header>
      <h1 class="company-title">Flight Dashboard</h1>
      <div class="menu-container">
        ${stringFromHtml(viewPicker.render())}
        <button data-header-reset>Reset</button>
      </div>
    </header>
  `);

  return rootEl;
}
