const path = require('path');

module.exports = {
  entry: './app.ts',
  mode: 'development',
  devServer: {
    allowedHosts: 'all',
    static: {
      directory: __dirname,
    },
    port: 8080,
    devMiddleware: {
      writeToDisk: true,
    },
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: ['.ts', '.js'],
  },
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
};