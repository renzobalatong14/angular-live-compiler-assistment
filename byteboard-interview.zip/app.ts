import {SelectedFlightData} from './data/selectedFlightData';
import {renderFlightDashboard} from './views/flightDashboard';
import {renderFlightCard} from './views/flightCard';

let rootEl = document.body;
const emptyRoot = rootEl.cloneNode()

function renderApp() {
  const flight = selectedFlightData.get('flight');

  // Clear document body and remove all event listeners
  rootEl.innerHTML = '';
  rootEl.replaceWith(emptyRoot.cloneNode());
  rootEl = document.body;
  const main =  document.body.appendChild(document.createElement('main'));
  main.className = 'main-container';

  if (flight === null) {
    // No selected flight, render list view
    main.appendChild(renderFlightDashboard(selectedFlightData));
  } else {
    // Render selected flight
    main.appendChild(renderFlightCard(selectedFlightData));
  }
}

export const selectedFlightData = new SelectedFlightData({
    flight: null,
    onChange: renderApp,
});

// Initial app render.
renderApp();
