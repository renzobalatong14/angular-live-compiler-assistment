/**
 * Confirms if an event object has the intended element origin
 */
export function verifyEvent(ev: Event, dataProp: string): boolean {
  let {target} = ev;

  while (target !== null && target instanceof HTMLElement) {
    if (target.dataset.hasOwnProperty(dataProp)) {
      return true;
    }
    target = target.parentElement;
  }
  return false;
}
