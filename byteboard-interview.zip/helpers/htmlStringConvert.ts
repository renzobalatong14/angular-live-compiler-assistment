/**
 * Creates a DOM element from a valid HTML string.
 */
export function htmlFromString(str: string): HTMLElement {
  const template = document.createElement('template');
  template.innerHTML = str.trim();
  return <HTMLElement>template.content.firstChild;
}

/**
 * Creates a string from a DOM selection.
 */
export function stringFromHtml(html: HTMLElement | null): string {
  if (html === null) return '';
  return html.outerHTML;
}
