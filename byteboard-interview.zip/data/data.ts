export class Data {
  changeCallbackFns: ((key: string) => void)[] = [];
  store: Record<string, any>;

  constructor(data: any) {
    const onChangeCallback = data.onChange;
    delete data.onChange;

    this.store = data;

    if (onChangeCallback) {
      this.onChange(onChangeCallback);
    }
  }

  get(key?: string) {
    return typeof key !== 'undefined' ? this.store[key] : this.store;
  }

  set(key: string, value: any) {
    this.store[key] = value;
    this.notify(key);
  }

  onChange(callbackFn: (key: string) => void) {
    if (!callbackFn || typeof callbackFn !== 'function') return;

    this.changeCallbackFns.push(callbackFn);

    return () => {
      this.changeCallbackFns.splice(this.changeCallbackFns.indexOf(callbackFn), 1);
    };
  }

  notify(key: string) {
    this.changeCallbackFns.forEach((callbackFn) => {
      callbackFn(key);
    });
  }
}
