import { Flight } from "../types";
import {Data} from "./data";

interface SelectedFlight {
    flight: Flight | null;
    onChange: (flight: Flight) => void;
}

const defaultProps: SelectedFlight = {
    flight: null,
    onChange: () => {}
}

export class SelectedFlightData extends Data {
    constructor(data: Partial<SelectedFlight>) {
        super({...defaultProps, ...data});
    }
}