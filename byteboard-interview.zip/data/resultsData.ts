import { Flight } from '../types';
import {Data} from './data';
import TEST_DATA from './testData';

interface Results {
  flights: Flight[];
  view: number;
  onChange: (key: string) => void;
}

interface FlightResponse {
  done: boolean;
  flights: Flight[]
}

/**
 * Default properties for Results
 */
const defaultProps: Results = {
  flights: [],
  view: 0,
  onChange: () => {},
};

export class ResultsData extends Data {
  constructor(data: Partial<Results>) {
    super({...defaultProps, ...data});

    this.updateFlightResults();
  }

  async updateFlightResults() {
    const results = await this.fetchFlightResults();
    this.set('flights', results);
  }

  /**
   * Loads the flight list data.
   */
  async fetchFlightResults(): Promise<Flight[]> {
    // TODO: Implement this function. See the README For more details.
    return TEST_DATA;
  }

}
