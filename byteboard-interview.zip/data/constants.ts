export const AIRPORT_CODE = "XYZ";

export const viewOptions: string[] = ["Arriving Flights", "Departing Flights"];
